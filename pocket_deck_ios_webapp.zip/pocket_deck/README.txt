POCKET DECK v2 — iPhone DJ web app (PWA)

WORKING MODES
1. YouTube videos: Tick the YouTube terms/privacy consent checkbox, paste a YouTube video URL (or video ID), then LOAD A/B. The video loads in the official visible YouTube IFrame Player API. Playback requires internet and video must allow embedding. No developer API key is needed for pasted links.
2. YouTube search: Create a free Google Cloud key, enable YouTube Data API v3, paste the key into DATA API KEY. Tick the consent checkbox, type a query, SEARCH, then tap DECK A / DECK B. Your key is held only in the page for this session; secure it with HTTP referrer restrictions at Google Cloud.
3. Local audio: Tap + TRACK to load an audio file from Files. Full jog scratching, cue, filter, speed, loop, echo, sync-by-manual-BPM, crossfade and optional recording.
4. Real four-stem mixer: Tap + 4 STEMS and choose four aligned audio files with filenames containing vocals/drums/bass/other. Adjust or mute the stems. TRY DEMO loads two original, synthesised four-stem loops to try without files.

IMPORTANT LIMITATIONS
- YouTube API does not provide downloadable raw MP3 audio. Its developer policies forbid isolating, altering and downloading audio from YouTube streams. YouTube videos use official visible iframes; local-file effects/stems/scratching never process YouTube sound. Recording captures only local audio. API volume adjustment on iOS is not guaranteed: use native video controls if necessary.
- This app does NOT automatically split a local song into stems. It mixes pre-separated files. Demo stems are procedurally synthesised, not separated from YouTube.
- For full recording and iOS Safari behaviour, functionality depends on browser permissions and OS version. Actual hardware iPhone audio tests have not been run in this environment.
- Some embedded videos may be blocked by the copyright holder. API search needs an API key and available quota. No AI tokens or paid server are used at runtime.

RUNNING THE WORKING WEBSITE
On a computer:
  cd pocket_deck_v2
  python3 -m http.server 8080
  open http://localhost:8080

On an iPhone:
  Upload the contents of this folder to any free static HTTPS host (e.g. GitHub Pages or Cloudflare Pages); the website cannot run from the ZIP directly as a fully functional PWA. Open the URL in Safari, Share > Add to Home Screen > Open as Web App.

The app shell is cached by a service worker for offline use, but YouTube playback and search require internet, and local imported audio is not saved between launches.

This is a functional technical prototype, not a native .ipa or App Store package. Native iOS delivery would require an Apple code-signing workflow.

YOUTUBE PLAYER ORIGIN: Use an HTTPS-hosted site with a proper Referer header. YouTube may show error 153 in local file/preview contexts and cannot be used as raw audio in a DJ engine. The official embed player must remain visible and at least 200 × 200 pixels.
