// Stand-alone unit test: runs the same AudioWorklet algorithm used in the app.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
const code=html.match(/const processorSource=`([\s\S]*?)`;\s*\/\* ScriptProcessor/)[1];
let Processor;
class Base{constructor(){this.port={postMessage:()=>{},onmessage:()=>{}}}}
vm.runInNewContext(code,{AudioWorkletProcessor:Base,registerProcessor:(name,P)=>{assert.equal(name,'pocket-deck');Processor=P;}});
const p=new Processor();
const N=2000;
const wave=Float32Array.from({length:N},(_,i)=>Math.sin(i*0.024)*.4);
p.port.onmessage({data:{cmd:'load',song:[wave],length:N}});
p.port.onmessage({data:{cmd:'play',value:true}});
const l=new Float32Array(128),r=new Float32Array(128);
p.process([] , [[l,r]]);
assert(l.some(x=>Math.abs(x)>0.01),'audio output should contain samples');
assert.deepEqual(Array.from(l),Array.from(r),'mono file should fill both stereo channels');
const old=p.pos;
p.port.onmessage({data:{cmd:'scrub',enabled:true,speed:-2}});
p.process([],[[l,r]]);assert(p.pos<old,'scratching backwards should move backwards');
p.port.onmessage({data:{cmd:'scrub',enabled:false,speed:0}});
p.port.onmessage({data:{cmd:'load',stems:[[wave],[wave],[wave],[wave]],length:N}});
p.port.onmessage({data:{cmd:'stemGains',values:[0,0,0,0]}});
p.port.onmessage({data:{cmd:'play',value:true}});
p.process([],[[l,r]]);assert(l.every(x=>x===0),'muted stems should be silent');
p.port.onmessage({data:{cmd:'stemGains',values:[1,0,0,0]}});
p.process([],[[l,r]]);assert(l.some(x=>Math.abs(x)>0.01),'unmuted stem should sound');
console.log('PASS AudioWorklet: playback, stereo, reverse scratch, stem mute and unmute');
